# CUMCM 2026 C题正式论文

主文件为`main.tex`，编译器为XeLaTeX，线上使用TeX Live 2025。工程保留正文实际引用的`sections`、`figures`和`tables`文件。

最终方案为：问题一采用LP主求解并由MILP和网格DP互证；问题二采用固定Ridge、0.8分位数安全余量和边际价值DP；问题三采用0.65/0.625分位数、六小时分段更新、双向策略调整和递减价值DP；问题四-2采用因果电价预测与边际价值DP；问题四-3沿用问题三控制结构并按实际电价结算。

当前论文共28页，问题三总费用为1320.7966万元，问题四-2和问题四-3总费用分别为1457.6456万元和1394.6759万元。正文图表数字来自仓库`results/c2026`中的最终结果。

本地编译：

```bash
latexmk -xelatex -interaction=nonstopmode -halt-on-error -outdir=build main.tex
```
